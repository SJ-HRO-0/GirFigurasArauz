public abstract class Figura {
    abstract double obtenerPerimetro();
    abstract double obtenerArea();
    abstract double obtenerVolumen();
}
